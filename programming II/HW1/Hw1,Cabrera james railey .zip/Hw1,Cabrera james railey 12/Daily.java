public class Daily extends Appt
{
    public static boolean specificAppointmentFound = false; 
    
    public Daily(int day, int month, int year, String description) 
    {
        super(day, month, year, description);
    }
    public boolean occursOn(int day, int month, int year) 
    {
        return (this.getYear() == year && this.getMonth() == month && this.getDay() == day);
    }
}


