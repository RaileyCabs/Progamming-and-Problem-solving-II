public class OneTime extends Appt
{
  public OneTime(int day, int month, int year, String description)
      {
        super(day, month, year, description);
      }
      public boolean occursOn(int day, int month, int year)
  {
      return(this.getDay() == day && this.getMonth() == month && this.getYear() == year);
  }
}


